//E - Subclass
public class achievements extends hobbies {

	String agreet = "Hello! Here is my achievement!";
	String dip = "Diploma";
	String gp = "Graduation Photo";
	String mc = "Medals and Certificate";

	public achievements() {
		super();
	}
}