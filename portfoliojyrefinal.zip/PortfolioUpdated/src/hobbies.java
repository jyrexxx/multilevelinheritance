//D - Subclass
public class hobbies extends personalInfo {

	String hgreet = "Hello! Here you will know my hobbies!";
	String watch = "Watching Anime";
	String play = "Playing Games";
	String dog = "Bonding with dogs";

	public hobbies() {
		super();
	}
}